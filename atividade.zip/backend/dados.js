const funcioarios = [
    {
        "matricula": 1223,
        "nome": "Tiago Santos de Jesus",
        "ramal": 200,
        "setor": "administração",
        "nascimento": "23/12/2000",
        "email": "tiagooogomes@gmail.com"	
      }, 
      {
        "matricula": 1122,
        "nome": "Ednilson Silva O. Junior",
        "ramal": 201,
        "setor": "administração",
        "nascimento": "22/11/2002",
        "email": "hunterd@hotmail.com"	
      }, 
      {
       "matricula": 1561,
       "nome": "Amanda Santos de Oliveira",
       "ramal": 202,
       "setor": "RH",
       "nascimento": "15/08/1992",
       "email": "amanda-gatta@hotmail.com"	
      }, 
      {
        "matricula": 1036, 
        "nome": "Socorro Jesus dos Santos",
        "ramal": 203,
        "setor": "operação",
        "nascimento": "25/01/2000",
        "email": "socorrojesus@gmail.com"
      },
      {
        "matricula": 2642,
        "nome": "Jaime Burbano",
        "ramal": 204,
        "setor": "RH",
        "nascimento": "26/10/2007",
        "email": "burbano@gmail.com"	
      }, 
      {
        "matricula": 2671,
        "nome": "Britney Spears",
        "ramal": 205,
        "setor": "operação",
        "nascimento": "01/01/1999",
        "email": "britneyestrela@yahoo.com"	
        }, 
      {
        "matricula": 6864,
        "nome": "Yasmin Agnes Santos da Silva",
        "ramal": 206,
        "setor": "RH",
        "nascimento": "30/12/1987",
        "email": "gatinhamanhosa@hotmail.com"	
        }, 
      {
        "matricula": 9864, 
        "nome": "Vilma Gomes dos Santos",
        "ramal": 207,
        "setor": "RH",
        "nascimento": "16/10/2003",
        "email": "vilmagomes@gmail.com"
      },
      {
        "matricula": 5912,
        "nome": "Arnon Henrique Barros Cavalcante Sousa",
        "ramal": 208,
        "setor": "comercial",
        "nascimento": "29/09/1995",
        "email": "arnonbarros@yahoo.com"	
      },
      {
        "matricula": 6818,
        "nome": "Debora Kaynara Patricio da Silva",
        "ramal": 209,
        "setor": "comercial",
        "nascimento": "26/04/1963",
        "email": "silvadebora@hotmail.com"	
      },
      {
        "matricula": 6906,
        "nome": "Maria Conceição da S. Souza",
        "ramal": 210,
        "setor": "financeiro",
        "nascimento": "29/12/1992",
        "email": "maria-gatta@gmail.com"	
      },
      {
        "matricula": 6813,
        "nome": "Simone Karla Costa da Silva",
        "ramal": 211,
        "setor": "operação",
        "nascimento": "05/09/2003",
        "email": "simone.mone@gmail.com"	
      },
      {
        "matricula": 3641,
        "nome": "Ramon Douglas Neves de Andrade",
        "ramal": 212,
        "setor": "operação",
        "nascimento": "07/11/1961",
        "email": "douglasneve@hotmail.com"	
      },
      {
        "matriculad": 7681,
        "nome": "Maria Gisele da Silva de Oliveira",
        "ramal": 213,
        "setor": "financeiro",
        "nascimento": "15/06/1995",
        "email": "gisele@yahoo.com.br"	
      },
      {
        "matricula": 2065,
        "nome": "Railma R. Medeiros da Silva",
        "ramal": 214,
        "setor": "comercial",
        "nascimento": "18/06/2000",
        "email": "railma.teste@gmail.com"	
      },
      {
        "matricula": 2006,
        "nome": "Ewertom Mascena de Araújo",
        "ramal": 215,
        "setor": "administração",
        "nascimento": "16/08/1996",
        "email": "mascena.ewertom@gmail.com"	
      },
      {
        "matricula": 3368,
        "nome": "Maryane Christine Teixeira da Costa",
        "ramal": 216,
        "setor": "financeiro",
        "nascimento": "13/10/1957",
        "email": "teixeira-costa@yahoo.com"	
      },
      {
        "matricula": 6005,
        "nome": "Saulo Matheus de Oliveira L. Cavalcante",
        "ramal": 217,
        "setor": "comercial",
        "nascimento": "18/04/2000",
        "email": "cavalcante_matheus@hotmail.com"	
      },
      {
        "matricula": 2424,
        "nome": "Victor Sthéfano de Moura Queiroz",
        "ramal": 218,
        "setor": "operação",
        "nascimento": "19/05/1963",
        "email": "sthefano-moura@gmail.com"	
      }
];

module.exports = funcioarios;